EDFP2SCII
=========

This is an extention for PROTOLIZE!2. It reads EDF+ files into a CSV file (with the header and the channels available) and a TXT file (containing the annotations channel, if available).

Requirements
------------

+ Visual C++